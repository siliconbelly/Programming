#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define BUFFER_SIZE 1024
#define SOCKET_ERROR -1

int main()
{
    int hServerSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (hServerSocket == SOCKET_ERROR)
    {
        puts("ERROR: 소켓을 만들 수 없습니다.");
        return 0;
    }

    struct sockaddr_in svraddr = { 0 };
    svraddr.sin_family = AF_INET;
    svraddr.sin_port = htons(8080);  
    svraddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(hServerSocket, (struct sockaddr*)&svraddr, sizeof(svraddr)) == SOCKET_ERROR)
    {
        puts("ERROR: 소켓을 바인드할 수 없습니다.");
        return 0;
    }

    if (listen(hServerSocket, SOMAXCONN) == SOCKET_ERROR)
    {
        puts("ERROR: 소켓에서 수신 대기할 수 없습니다.");
        return 0;
    }

    while (1)
    {
        int hClientSocket = accept(hServerSocket, NULL, NULL);
        if (hClientSocket == SOCKET_ERROR)
        {
            puts("ERROR: 클라이언트를 수락할 수 없습니다.");
            continue;
        }

        char szRequest[BUFFER_SIZE];
        int nReceive = recv(hClientSocket, szRequest, sizeof(szRequest), 0);

        if (nReceive == SOCKET_ERROR)
        {
            puts("ERROR: 클라이언트에서 데이터를 수신하지 못했습니다.");
            close(hClientSocket);
            continue;
        }

        char szResponse[] = "HTTP/1.1 200 OK\r\nContent-Length: 30\r\nContent-Type: text/plain\r\n\r\nP4C_3W_Homework_KIMHEEJUN\0";
        send(hClientSocket, szResponse, strlen(szResponse), 0);


        close(hClientSocket);
    }

    close(hServerSocket);

    return 0;
}
