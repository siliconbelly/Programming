#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define BUFFER_SIZE 1024
// 코드를 보기 쉽게 에러가 나는 상황을 #define을 통해 선언
#define SOCKET_ERROR -1


int main()
{
    int hServerSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (hServerSocket == SOCKET_ERROR)
    {
        puts("ERROR: 소켓을 만들 수 없습니다.");
        return 0;
    }

    //소켓을 생성하고, 소켓 구조체 변수인 svraddr을 초기화 해준다.
    //포트 번호 8080번을 사용하여 연결을 대기한다. 
    struct sockaddr_in svraddr = { 0 };
    svraddr.sin_family = AF_INET;
    svraddr.sin_port = htons(8080);  
    svraddr.sin_addr.s_addr = INADDR_ANY;

    // bind() 함수를 사용하여 소켓과 IP 주소, 포트 번호를 결합해준다.
    if (bind(hServerSocket, (struct sockaddr*)&svraddr, sizeof(svraddr)) == SOCKET_ERROR)
    {
        // 만약 bind() 함수가 실패하면 "ERROR: 소켓을 바인드할 수 없습니다."라는 메시지가 출력된다.
        puts("ERROR: 소켓을 바인드할 수 없습니다.");
        return 0;
    }

    // listen() 함수를 통해 소켓을 대기 상태로 만들어준다.
    // SOMAXCONN을 통해 연결 대기 큐의 최대 크기를 자동적으로 설정하게끔 해준다.
    if (listen(hServerSocket, SOMAXCONN) == SOCKET_ERROR)
    {
        //listen() 함수가 실패하면 "ERROR: 소켓에서 수신 대기할 수 없습니다."라는 메시지가 출력된다.
        puts("ERROR: 소켓에서 수신 대기할 수 없습니다.");
        return 0;
    }

    while (1)
    {
        //accept() 함수를 통해 클라이언트와 연결된 새로운 소켓을 생성해준다.
        int hClientSocket = accept(hServerSocket, NULL, NULL);
        if (hClientSocket == SOCKET_ERROR)
        {
            //accept() 함수가 실패하면 "ERROR: 클라이언트를 수락할 수 없습니다."라는 메시지가 출력된다.
            puts("ERROR: 클라이언트를 수락할 수 없습니다.");
            continue;
        }

        char szRequest[BUFFER_SIZE];
        // recv() 함수를 사용하여 클라이언트로부터 데이터를 수신해준다. 
        int nReceive = recv(hClientSocket, szRequest, sizeof(szRequest), 0);

        if (nReceive == SOCKET_ERROR)
        {
            //recv() 함수가 실패하면 "ERROR: 클라이언트에서 데이터를 수신하지 못했습니다."라는 메시지가 출력된다.
            puts("ERROR: 클라이언트에서 데이터를 수신하지 못했습니다.");
            close(hClientSocket);
            continue;
        }

        // send() 함수를 통해 클라이언트에게 응답 데이터를 전송해준다.. 
        //이 때의 응답 데이터는 HTTP/1.1 200 OK\r\nContent... 이후까지.
        //Content-Length와 Content-Type 헤더를 통해 표현하고자 하는 타입을 설정해주었다.
        char szResponse[] = "HTTP/1.1 200 OK\r\nContent-Length: 30\r\nContent-Type: text/plain\r\n\r\nP4C_3W_Homework_KIMHEEJUN\0";
        send(hClientSocket, szResponse, strlen(szResponse), 0);


        close(hClientSocket);
    }
    //close() 함수를 사용하여 소켓을 닫아준다. 
    close(hServerSocket);

    return 0;
}
