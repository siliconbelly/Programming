#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define BUFFER_SIZE 1024
// 코드를 보기 쉽게 에러가 나는 상황을 #define을 통해 선언
#define SOCKET_ERROR -1

int main()
{
    //소켓을 생성
    int hSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (hSocket == SOCKET_ERROR)
    {
        //오류 메시지 반환
        puts("ERROR: 소켓을 만들 수 없습니다.");
        return 0;
    }

    struct sockaddr_in svraddr = { 0 };
    svraddr.sin_family = AF_INET;
    // 서버 포트번호
    svraddr.sin_port = htons(8080);  
    // 서버 IP 주소
    svraddr.sin_addr.s_addr = inet_addr("127.0.0.1");  

    // 서버의 IP 주소와 포트 번호를 설정하여 서버에 연결을 시도해준다.
    if (connect(hSocket, (struct sockaddr*)&svraddr, sizeof(svraddr)) == SOCKET_ERROR)
    {
        //에러 메시지 반환
        puts("ERROR: 서버에 연결할 수 없습니다.");
        return 0;
    }

    // GET 요청 메시지를 생성하여 서버로 전송해준다. 
    // 메시지를 "127.0.0.1"로 설정된 로컬 호스트에 있는 서버로 전송해준다. 
    char szRequest[BUFFER_SIZE];
    sprintf(szRequest, "GET / HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n");

    send(hSocket, szRequest, strlen(szRequest), 0);

    char szResponse[BUFFER_SIZE];
    int nReceive = 0;

    //서버로부터 응답 메시지를 받을 때까지 반복문을 실행해준다.
    while ((nReceive = recv(hSocket, szResponse, sizeof(szResponse), 0)) > 0)
    {
        szResponse[nReceive] = '\0';
        // 응답 메시지를 받을 때마다 받은 데이터를 출력해준다.
        printf("%s", szResponse);
    }

    if (nReceive == SOCKET_ERROR)
    {
        // 서버에서 데이터를 받지 못할때 에러 메시지를 출력해준다. 
        puts("ERROR: 서버에서 데이터를 받지 못했습니다.");
    }
    // 소켓을 닫고 프로그램을 종료
    close(hSocket);

    return 0;
}