#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#define BUFFER_SIZE 1024
#define SOCKET_ERROR -1

int main()
{
    int hSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (hSocket == SOCKET_ERROR)
    {
        puts("ERROR: 소켓을 만들 수 없습니다.");
        return 0;
    }

    struct sockaddr_in svraddr = { 0 };
    svraddr.sin_family = AF_INET;
    svraddr.sin_port = htons(8080); 
    svraddr.sin_addr.s_addr = inet_addr("127.0.0.1");  

    if (connect(hSocket, (struct sockaddr*)&svraddr, sizeof(svraddr)) == SOCKET_ERROR)
    {
        puts("ERROR: 서버에 연결할 수 없습니다.");
        return 0;
    }

    char szRequest[BUFFER_SIZE];
    sprintf(szRequest, "GET / HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n");

    send(hSocket, szRequest, strlen(szRequest), 0);

    char szResponse[BUFFER_SIZE];
    int nReceive = 0;

    while ((nReceive = recv(hSocket, szResponse, sizeof(szResponse), 0)) > 0)
    {
        szResponse[nReceive] = '\0';
        printf("%s", szResponse);
    }

    if (nReceive == SOCKET_ERROR)
    {
        puts("ERROR: 서버에서 데이터를 받지 못했습니다.");
    }

    close(hSocket);

    return 0;
}